/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receptkonyv;

import java.util.ArrayList;

/**
 *
 * @author nemet
 */
public class Alapanyag extends ReceptJFrame {
    
    private String nev;
    private int mennyiseg;
    private String mertekegyseg;
    private String recNev;
    
    public Alapanyag(String nev,int mennyiseg,String mertekegyseg,String recNev){
        
        this.nev = nev;
        this.mennyiseg = mennyiseg;
        this.mertekegyseg = mertekegyseg;
        this.recNev=recNev;
    }
    
    
    public void setNev(String nev){
        this.nev=nev;
    }
    public void setMennyiseg(int mennyiseg){
        this.mennyiseg=mennyiseg;
    }
    public String getNev(){
        return this.nev;
    }
    public int getMennyiseg(){
        return this.mennyiseg;
    }
    public void setMertekegyseg(String mertekegyseg){
    
        this.mertekegyseg = mertekegyseg;
    }
    public String getMertekegyseg(){
    
        return this.mertekegyseg;
    }
    public String getrecNev(){
        return this.recNev;
    }
    public void setrecNev(String recNev){
        this.recNev = recNev;
    }
}
