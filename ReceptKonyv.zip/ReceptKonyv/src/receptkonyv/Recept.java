/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receptkonyv;

import java.awt.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author nemet
 */
public class Recept extends ReceptJFrame {
    
   
    private String nev;
    private int alap; //alapanyag db-szám
    private int szemelyre;
    
    public Recept(String nev,int szemelyre,int alap){
    
        this.nev = nev;
        this.szemelyre=szemelyre;
        this.alap=alap;
    }
    
    public void setNev(String nev){
        this.nev=nev;
    }
    public void setAlap(int alap){
        this.alap=alap;
    }
    public void setSzemelyre(int szemelyre){
        this.szemelyre=szemelyre;
    }
    public String getNev(){
        return this.nev;
    }
    public int getAlap(){
        return this.alap;
    }
    public int getSzemelyre(){
        return this.szemelyre;
    }
    
    public int Szemelyre(){
        int hanyra = 0;
        return hanyra;
    }
    
}
