/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receptkonyv;

import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author nemet
 */
public class DataBase {
    
    protected Connection con;
    public DataBase(Connection con){
        this.con = con;
    }
     void Connect()
     {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/receptes?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
            //JOptionPane.showMessageDialog(null, "Kapcsolódva");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Hiba!"+ex);
        }

    }
     
     void beleMent(ArrayList<Recept> re,ArrayList<Alapanyag>ar) throws SQLException{
         
         try{
         
         Connect();
         String sql;
         String sql2;
         
         for(int i= 0; i < re.size(); i++){
             
            sql = "INSERT INTO receptek (nev, alap, szemelyre) VALUES (?,?,?)";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,re.get(i).getNev());
            ps.setInt(2,re.get(i).getAlap());
            ps.setInt(3,re.get(i).getSzemelyre());
            ps.executeUpdate();
         }
         
         
         for(int x = 0;x < ar.size(); x++){
             
            sql2 = "INSERT INTO alapanyagok (nev, mennyiseg,mertekegyseg,receptnev) VALUES (?,?,?,?)";
            PreparedStatement px=con.prepareStatement(sql2);
            px.setString(1,ar.get(x).getNev());
            px.setInt(2,ar.get(x).getMennyiseg());
            px.setString(3,ar.get(x).getMertekegyseg());
            px.setString(4,ar.get(x).getrecNev());
            //ps.setInt(3,re.get(0).getSzemelyre());
            px.executeUpdate();
         
         }
         ar.clear();
         re.clear();
         con.close();
         JOptionPane.showMessageDialog(null,"ELmentve!");
         }
      
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        }
     
    
     
        
   }

